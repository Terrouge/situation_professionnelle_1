# database projet_thelp adam doursiev : script pour generer la DateBase en local sur MAMP

CREATE DATABASE projet_thelp;

## table users

CREATE TABLE `projet_thelp`.`users` ( id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, username VARCHAR(50) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP );

## table type_appreciation

CREATE TABLE `projet_thelp`.`type_appreciation` ( id INT NOT NULL AUTO_INCREMENT ,trimestre INT(3) NOT NULL , nom_type VARCHAR(70) NOT NULL , PRIMARY KEY (id));
### trimestre 1

INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (1,'Mauvais trimestre');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (1,'Trimestre décevant');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (1,'Elève ayant des difficultés');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (1,'Niveau juste');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (1,'Absences');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (1,'Trimestre correct mais le minimum est fait');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (1,'Redoublement');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (1,'Bon début mais baisse de régime');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (1,'Bon travail mais attitude à revoir');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (1,'Bon bilan car élève positif');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (1,'Bon trimestre voire très bon');

### trimestre 2

INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (2,'Mauvais trimestre');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (2,'Trimestre décevant');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (2,'Elève ayant des difficultés');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (2,'Niveau juste');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (2,'Trimestre correct mais le minimum est fait');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (2,'Trimestre identique au précédent');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (2,'Chute des résultats mais le bilan reste correct');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (2,'Bon travail mais attitude à revoir');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (2,'Elève positif');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (2,'Progression des résultats');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (2,'Bon trimestre voire très bon');

### trimestre 3

INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (3,'Absences');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (3,'Réorientation, redoublement');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (3,'Bilan annuel terne');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (3,'Manque de motivation, de concentration');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (3,'Année prochaine difficile');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (3,'Méritants, méritantes');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (3,'Progression, garder le même rythme');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (3,'Bilan annuel satisfaisant');
INSERT INTO `projet_thelp`.`type_appreciation`(`trimestre`, `nom_type`) VALUES (3,'I am not rapper');


## table list_appreciation

CREATE TABLE `projet_thelp`.`list_appreciation` ( id INT NOT NULL AUTO_INCREMENT ,appreciation TEXT NOT NULL , id_type INT NOT NULL , PRIMARY KEY (id));
## cle etranger

ALTER TABLE `projet_thelp`.`list_appreciation` ADD CONSTRAINT `fk_id_type` FOREIGN KEY (`id_type`) REFERENCES `type_appreciation`(`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

###trimestre 1

#### 1 T1

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a beaucoup de difficultés dues à des lacunes mais aussi à un manque de travail qui ne permet pas de les combler. Il faut s\'y mettre au prochain trimestre.',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail de [prenom] n\'est pas assez soutenu pour prétendre à de meilleurs résultats. Il faut s\'impliquer davantage.',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un début d\'année catastrophique, dû à une absence totale de travail personnel. [prenom] faut se mettre sérieusement au boulot.',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Je me demande si [prenom] a ouvert un cahier depuis le début de l\'année.',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les résultats sont insuffisants et la participation quasiment inexistante. [prenom] va devoir faire un effort conséquent au second trimestre pour montrer sa motivation.',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('L\'ensemble est insuffisant, [prenom] doit se concentrer davantage en classe et fournir un travail personnel plus conséquent. J\'attends mieux au second trimestre.',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] n\'apprend pas assez consciencieusement son cours. Y remédier devrait lui permettre d\'avoir de meilleurs résultats au prochain trimestre.',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a une présence beaucoup trop passive en cours.',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail de [prenom] n\'est pas régulier, que ce soit au niveau du sérieux qu’au niveau du travail. J\'attends beaucoup mieux au prochain trimestre.',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('L\'attitude de [prenom] est difficile a saisir, capable du meilleur comme du pire. Mais pour le moment son travail n’est pas assez soutenu. Il faut s’y mettre sérieusement au prochain trimestre.',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un trimestre en dents de scie. [prenom] ne travaille pas régulièrement. Cette attitude doit changer pour le prochain trimestre.',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Ne fourni aucun travail. [prenom] ne peut réussir ainsi.',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Comportement de [prenom] est trop passif, il faut rester concentrée en classe et travailler plus consciencieusement pour progresser. ',1);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] n\'est pas au niveau et ne travaille pas suffisamment pour rattraper son retard. J\'attends beaucoup mieux au prochain trimestre. ',1);

#### 2

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Je n’ai pas l\'impression que [prenom] fournisse beaucoup de Travail. C\'est dommage car il me semble capable de mieux.',2);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail n\'a pas toujours été sérieux, ce qui pénalise un peu. [prenom] semble s\'être ressaisie, la moyenne devrait donc être meilleure au prochain trimestre. ',2);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('L\'ensemble est un peu juste. Je regrette une trop grande passivité en cours et un manque d\'investissement personnel de [prenom].',2);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('L\'ensemble est un peu décevant [prenom] participe timidement et ses résultats sont en dents de scie. Le comportement de [prenom] est pourtant attentif en classe. J\'attends mieux au deuxième trimestre.',2);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le niveau de [prenom] est juste, le travail n’était pour le moment pas assez soutenu.',2);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le niveau de [prenom] est juste, des difficultés et ne travaille pas suffisamment pour essayer d\'y palier.',2);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] est en dessous du niveau, pourtant semble faire quelques efforts. Il faut essayer de se relancer sur les prochains chapitres.',2);


#### 3

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Des difficultés certaines, mais de la bonne volonté. Il ne faut pas que [prenom] relâche ses efforts, devrait pouvoir combler ses lacunes et rattraper son retard.',3);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a beaucoup de difficultés à suivre le rythme. Peut-être un problème d\'organisation du travail ? Il faut essayer de se relancer avec les prochains chapitres et le début du deuxième trimestre.',3);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] manque de méthode, cela se voit dans ses contrôles, mais ce doit être le cas pour le travail à la maison. Il faut s\'organiser pour un travail efficace.',3);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a des difficultés. En restant concentrée, les résultats vont s\'améliorer.',3);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a des difficultés mais le comportement semble sérieux. Il ne faut pas relâcher ses efforts, les résultats devraient progresser.',3);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le niveau de [prenom] est juste. Peut-être est-ce un problème de méthode car le comportement semble sérieuse. Il faut revoir ses méthodes d\'apprentissage.',3);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a des difficultés, il faut se concentre davantage pour pouvoir palier à celles-ci.',3);

#### 4

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un début d\'année en douceur pour [prenom]. Il faut nous montre de quoi [prenom] est capable au prochain trimestre. Il faut plus d\'implication dans le travail pour réussir.',4);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] nous propose un trimestre moyen, parait impliquée en classe mais il faut que le travail à la maison soit plus approfondi. On attend mieux au prochain trimestre.',4);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] ne doit pas baisser les bras. Il ne faut pas hésiter a demander de l\'aide et à poser des questions. Le prochain trimestre doit être meilleur.',4);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un niveau assez juste pour [prenom], il faut persévérer dans le travail et les résultats augmenteront.',4);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le début de l\'année fut un peu difficile mais [prenom] semble s’être ressaisie, devrait progresser encore au prochain trimestre. Attention à bien rester concentrée en classe.',4);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] participe de plus en plus, ce qui permet de constater qu\'il a de bonnes connaissances dans certains domaines. II faudrait maintenant approfondir le travail personnel.',4);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('L\'ensemble est un peu juste, il faut régulièrement rappeler à l\'ordre [prenom] qui a tendance à se laisser aller. C\'est dommage, [prenom] a des capacités qui ne sont pas exploitées totalement.',4);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('L\'ensemble est un peu juste. [prenom] manque de confiance. Il faut accroître encore la participation en classe afin de progresser plus rapidement. Je l\'encourage.',4);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] participe régulièrement. Mais il faut accentuer son travail personnel pour pouvoir progresser.',4);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('L\'ensemble est un peu juste [prenom] doit apprendre plus régulièrement et de manière plus rigoureuse ses leçons.',4);

#### 5

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Peu de notes pour juger réellement le niveau de [prenom] mais j\'ai pu constater au début de l\'année une bonne participation et un sérieux dans le travail. Il ne devrait donc pas y avoir de soucis au prochain trimestre.',5);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Des absences nombreuses en début de trimestre n\'ont pas permis à [prenom] de suivre correctement les cours. Mais [prenom] me semble fragile dans cette matière. Il faut continuer à travailler et les résultats progresseront.',5);

#### 6

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Assez bien. [prenom] pourrait progresser plus vite, en se donnant vraiment la peine.',6);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('L\'ensemble est correct mais [prenom] pourra certainement progresser au second trimestre en faisant davantage d\'efforts de participation et dans le travail personnel.',6);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Ensemble assez correct. [prenom] doit participer davantage et sans doute fournir un travail personnel plus conséquent.',6);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Ensemble correct mais [prenom] ne donne pas le meilleur de lui même.',6);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('C\'est un peu juste pour un premier trimestre, [prenom] est certainement capable de beaucoup mieux en s\'en donnant un peu plus la peine.',6);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Ensemble correct mais [prenom] ne se donne pas tous les moyens pour obtenir de meilleurs résultats. J\'attends mieux au deuxième trimestre.',6);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] donne l\'impression de faire le minimum, s\'en sort pour le moment mais est-ce que ça va durer ?',6);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] fait le minimum, il faut être plus éveiller pour améliorer ses résultats.',6);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] en fait le minimum, c\'est bien dommage car capable de bien mieux. J\'attends un changement pour le prochain trimestre.',6);

#### 7

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le niveau de [prenom] est juste, il faut fournir plus de travail pour que son redoublement lui soit vraiment profitable.',7);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Il semble que [prenom] obtient ses notes avec ses acquis de l\'an passé. Avec plus de travail personnel, les résultats pourraient être bien meilleurs.',7);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le redoublement de [prenom] ne lui sera pas profitable s’il se contente de ses acquis. Il faut plus de travail personnel.',7);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] semble travailler et son niveau est correct. Pour que son redoublement lui soit encore plus profitable, il faut qu\'il mette l\'accent sur ses lacunes.',7);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Bon trimestre. [prenom] continue ses efforts en français et progresse d\'année en année. Je l\'encourage.',7);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Quel changement (positif) par rapport à l\'année dernière. [prenom] travaille plus sérieusement, il fait davantage d\'efforts, il participe. C\'est un vrai plaisir de constater ce changement. Je l\'encourage.',7);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] est nettement plus active cette année et les résultats tout à fait corrects. Continue ainsi.',7);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le comportement de [prenom] est plus actif en classe cette année, c\'est une bonne initiative. Attention toutefois à ne pas se déconcentrer. Pour voir ses notes progresser, il faut travailler régulièrement et apprendre de manière approfondie ses leçons.',7);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un premier trimestre plutôt correct, mais [prenom] reste sur ses acquis de l\'an passé, cela risque de ne pas suffire pour les prochains trimestres.',7);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] ne s\'est servi que de ses acquis de l\'an passé pour ce premier trimestre. II faut qu\'il s’implique davantage dans le travail pour progresser.',7);

#### 8

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le niveau de [prenom] est juste, il faut fournir plus de travail.',8);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Il semble que [prenom] obtient ses notes avec ses acquis de l\'an passé. Avec plus de travail personnel, les résultats pourraient être bien meilleurs.',8);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] ne doit pas se contenter de ses acquis. Il faut plus de travail personnel.',8);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] semble travailler et son niveau est correct. Mais baisse de régime en fin de semestre',8);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] est capable mais doit maintenir son régime de travail du début.',8);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail de [prenom] était nettement plus productif en début d\'année. Il ne faut pas rester sur ces acquis.',8);

#### 9

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Ensemble correct mais [prenom] peut se déconcentrer rapidement.',9);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Ensemble correct mais [prenom] attention aux bavardages.',9);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Très bon trimestre mais [prenom] attention aux bavardages.',9);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Bon trimestre mais [prenom] doit apprendre à se concentrer durablement et faire attention à son comportement en classe.',9);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('C\'est très bien. Attention cependant au comportement en classe.',9);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Bon trimestre dans l\'ensemble mais [prenom] manque d\'assiduité dans son attitude en classe.]',9);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les résultats de [prenom] sont corrects, c\'est l\'attitude en classe, face au professeur et aux élèves, qui doit être modifiée. Un peu moins de nonchalance et un peu plus de respect.',9);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un trimestre en dents de scie, mais le niveau reste correct Je pense que plus de concentration en classe serait profitable à [prenom].',9);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] s\'en sort plutôt bien malgré une grande passivité en classe. Un minimum de travail durant les cours serait bienvenu.',9);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un niveau correct et un travail sérieux, mais il faut un peu plus de concentration pour progresser.',9);

#### 10

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] s\'applique au travail ce qui vient de payer au dernier contrôle. II faut poursuivre ses efforts.',10);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] tient le bon bout. Il faut continuer à travailler pour que les résultats progressent encore.',10);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] est volontaire dans sa réussite et doit continuer ainsi.',10);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le bilan est positif, [prenom] tire profit de cette classe et fait des efforts. Je l\'encourage à continuer ainsi, il devrait bien progresser tout au long de l\'année avec une telle attitude.',10);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] tire profit de se retrouver dans cette classe. I1 progresse, lentement et sûrement. Il faut s\'accrocher et continuer ainsi.',10);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Bon trimestre. [prenom] à une attitude très attentive, très concentrée. [prenom] se donne beaucoup de mal pour obtenir de bons résultats. Il faut continuer ainsi.',10);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] m\'a rendu un très bon contrôle, une attitude positive, il faut tenir bon.',10);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] fait de gros efforts pour bien se tenir en classe, pour suivre le rythme et cela paie. Je l\'encourage à rester sur cette voie qui ne peut que lui être profitable.',10);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a commencé l\'année tout en douceur, mais la fin de ce trimestre est satisfaisante. II faut continuer ainsi, c\'est encourageant.',10);

#### 11

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail de [prenom] est assez bon dans l\'ensemble. C\'est encourageant pour le prochain trimestre.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] fait un début d\'année satisfaisant ce qui est encourageant pour la suite.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un début d\'année en dents de scie, mais le niveau est correct. Il faut plus de régularité à [prenom] pour progresser.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un début d\'année correct pour [prenom] et à poursuivre pour le prochain trimestre.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Bon travail de [prenom]. C\'est tout a fait encourageant.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail fourni de [prenom] parait correct, il faut maintenant prendre confiance en soi.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Très bien. De plus [prenom] fait preuve d\'une bonne curiosité pour ces cours.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Bon trimestre de [prenom]. Je l’encourage à continuer.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('C\'est vraiment très bien, tant au niveau des résultats que de l\'attitude en classe pour [prenom]. Félicitation.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('C\'est un très bon trimestre. [prenom] travaille sérieusment et fait des efforts pour participer. Félicitation.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('C\'est un très bon ensemble. Le travail de [prenom] est sérieux et régulier. Continue ainsi.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une excellente participation de [prenom] à l\'oral. Quant aux résultats, ils sont tout à fait satisfaisants. Continue ainsi.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('L\'ensemble est correct et la participation très régulière et très pertinente. Continue ainsi [prenom].',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Comportement positif. [prenom] comble peu à peu ses lacunes. C\'est bien, il faut continuer ainsi. ',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail de [prenom] est très dynamique et actif. Continue ainsi.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('C\'est très bien. Bonne participation. Attitude très positive. [prenom] doit continuer ainsi.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Bon trimestre. [prenom] doit prendre en confiance et ne pas hésiter à poser des questions.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Très bon trimestre. [prenom] sait s’adapter aux méthodes de travail et se remettre à niveau quand c\'était nécessaire. Très bonne participation.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail de [prenom] est sérieux, le niveau correct, il faut continuer ainsi.',11);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les réflexions de [prenom] sont intéressantes et le travail sérieux, continuez ainsi.',11);

#### 12 T2

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] n\'ayant pas tenu compte des conseils du premier trimestre, les lacunes s\'accumulent.',12);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les résultats et le manque d\'implication de [prenom] sont très inquiétants.',12);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Je ne peux connaitre les véritables capacités de [prenom] puisqu\'il y a aucun travail fourni.',12);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les résultats parlent d\'eux-mêmes. [prenom] est souvent dans les nuages.',12);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Trop peu d\'investissement de [prenom] ce trimestre, il ne peut réussir ainsi.',12);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un trimestre catastrophique de [prenom], des difficultés de compréhension n\'ont pas été compensées par un travail personnel suffisant.',12);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] n\'a fait aucun effort ce trimestre, ce qui explique cette moyenne catastrophique.',12);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] baisse les bras progressivement.',12);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un manque certain de motivation de [prenom] qui ne pardonne pas. II faut travailler régulièrement pour réussir.',12);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une démission de [prenom] ce trimestre qui ne pardonne pas.',12);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Il semble que [prenom] abandonne cette matière. C\'est très décevant.',12);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] semble avoir mis cette matière de côté dans son cursus, malheureusement.',12);

#### 13 

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] stagne à un petit niveau. Il faut s\'impliquer davantage dans son travail personnel.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('L\'implication de [prenom] du premier trimestre a disparu ce qui provoque une petite baisse des résultats. Il faut se reconcentrer.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une chute inquiétante ce trimestre. [prenom] manque de motivation ce trimestre, il faut retrouver de l\'engouement pour réussir la fin de l\'année.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les résultats de [prenom] ont nettement baissés, cela est dû à un manque de motivation.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un niveau beaucoup trop juste qui est le résultat d\'un travail trop sporadique de la part de [prenom].',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] ne semble pas avoir pris conscience de l\'enjeu de son année et c\'est bien dommage.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Cette moyenne se passe de commentaires, [prenom] a baissé les bras ce trimestre.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Quelle catastrophe, [prenom] est pourtant capable de beaucoup mieux.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les résultats de [prenom] sont assez faibles ce trimestre. A suivre.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] en plus de ses difficultés, plus aucun travail est fourni et c\'est bien dommage.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] fait des efforts de travail en classe, par moments. Mais je ne pense pas que les notions soient reprises à la maison.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une chute des résultats notamment due à une baisse de motivation. Cependant, il semble que [prenom] veuille repartir sur de bonnes bases pour la fin de l\'année.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail est resté sérieux malgré une baisse de motivation. J\'espère un troisième trimestre à la hauteur du premier pour [prenom].',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une mauvaise période pour [prenom], l\'investissement personnel a été certainement moins sérieux.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Il semble y avoir une période difficile entre les deux trimestres pour [prenom]. Il faut relancer la machine pour la fin de l\'année.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Bon début de trimestre pour [prenom], mais la fin est décevante. Il faut plus de régularité dans le travail pour progresser.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le trimestre de [prenom] est assez décevant. Il faut cesser de se disperser et se remettre sérieusement au travail.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a fait preuve de meilleurs résultats. Mais la dose de travail personnel reste trop timide. Changer ça devrait faire une fin d\'année meilleure.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('On remarque un petit changement d\'attitude de [prenom] ces derniers temps. Cela expliquerait la chute de sa moyenne',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une grosse chute des résultats ce trimestre pour [prenom], le niveau s’étant élevé, il faut plus de travail personnel.',13);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] se déconcentre, il faut se ressaisir afin de revenir à son meilleur niveau',13);

#### 14

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les difficultés de [prenom] persistent, surtout dans la compréhension des leçons. Peut-être qu\'un approfondissement des exercices permettrait de mieux s\'approprier les notions.',14);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les bonnes méthodes d\'apprentissage sont absences chez [prenom]. Le niveau reste juste malgré l\'implication en classe.',14);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Des difficultés de compréhension sur des notions difficiles ont fait chuter les notes de [prenom]. Il faut se relancer avec les prochaines leçons.',14);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Ce trimestre a été beaucoup plus difficile pour [prenom], du fait de la complexité des notions abordées. Il faut tenter de se relancer avec les nouvelles leçons.',14);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('La complexité des notions abordées n\'a pas permis à [prenom] de maintenir son niveau du premier trimestre. Il ne faut pas baisser les bras et se relancer sur les nouvelles leçons.',14);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Des difficultés pour [prenom] dans cette matière, mais le sérieux est là. Continuer à travailler sérieusement doit lui permettre de faire un troisième trimestre de meilleure qualité.',14);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Ce trimestre a été plus compliqué pour [prenom], du fait d\'une augmentation du niveau. Il faut s\'accrocher.',14);

#### 15

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une petite remontée ce trimestre pour [prenom], mais le niveau est encore un peu juste. Il faut s\'impliquer davantage.',15);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Malgré la progression, [prenom] semble peu à peu lâcher prise, cela se voit dans sa motivation en classe.',15);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un trimestre moyen dû notamment à des notes en dents de scie. [prenom] devrait progresser avec plus de régularité dans le travail.',15);

#### 16

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('J\'ai l\'impression que [prenom] se contente de ces notes moyennes, pourtant capable de beaucoup plus, ce que j\'attends au prochain trimestre.',16);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('On ne peut pas dire que [prenom] se tue au travail ! Son niveau reste acceptable, mais capable de beaucoup plus.',16);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un trimestre en dents de scie pour [prenom], probablement le fruit d\'un travail personnel qui suit la même courbe. Plus de régularité lui permettra d\'obtenir de bons résultats.',16);

#### 17

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un trimestre équivalent au précédent. L\'implication de [prenom] dans son travail personnel doit lui permettre d\'accroître son niveau.',17);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Trimestre identique au précédent pour [prenom]. Continuer dans ce rythme.',17);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un trimestre équivalent au précédent pour [prenom], c\'est à dire de qualité.',17);

#### 18

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Petite baisse tout au long du trimestre pour [prenom], mais le travail reste sérieux.',18);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le trimestre avait bien débuté, malheureusement une note a fait chuter la moyenne. Le niveau reste cependant tout à fait correct.',18);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une baisse significative des résultats qui est peut-être due à la difficulté des notions abordées. Le niveau de [prenom] reste tout à fait correct.',18);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Il semble que [prenom] se soit un peu moins impliquée ce trimestre ce qui lui vaut cette petite baisse. Toutefois, le travail de [prenom] reste plutôt de qualité.',18);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le début du trimestre était bon pour [prenom], mais la fin plus difficile. L\'ensemble est cependant convenable.',18);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un trimestre tout aussi satisfaisant que le premier de la part de [prenom], même si on constate une baisse due aux difficultés des notions abordées.',18);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Peut-être un petit relâchement de [prenom] ce trimestre mais dans l\'ensemble, le niveau est plutôt correct.',18);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail de [prenom] est toujours sérieux malgré cette baisse des résultats.',18);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une petite baisse de résultats ce trimestre mais le travail de [prenom] reste sérieux.',18);

#### 19

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] se réveille ce trimestre. Je note cependant encore un petit problème de concentration.',19);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un bon trimestre, surtout au niveau notes. Mais la concentration en classe reste très limitée. Les notes de ce trimestre ont été comme la motivation de [prenom], en dents de scie. Son niveau reste toutefois satisfaisant.',19);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un manque de concentration de la part de [prenom] et cela nuit à ses résultats.',19);

#### 20

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Il ne faut pas que [prenom] se décourage car je sens que la motivation est présente. La difficulté se situe toujours au même endroit, dans la rapidité de réflexion.',20);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail de [prenom] semble plus sérieux, mais quelques lacunes du début d\'année. Le troisième trimestre devrait être meilleur.',20);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Malgré une attitude positive de [prenom], mais des difficultés sont présentes.',20);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('L\'attitude de [prenom] est impliqué, mais ses résultats sont trop irréguliers. Cette régularité dans le travail personnel est la clé de la réussite du troisième trimestre.',20);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les dernières semaines de [prenom] sont plus positives. Cette implication doit payer au prochain trimestre.',20);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('La difficulté des leçons s\'étant accrue. Malgré de la bonne volonté de [prenom], le rythme a chuté. Il faut tenter de se reprendre sur les nouvelles notions récemment abordées.',20);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail de [prenom] est resté sérieux, la baisse n\'étant due qu\'à la difficulté des notions abordées.',20);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le sérieux de [prenom] semble payer en fin de trimestre. Rester dans cet état d\'esprit devrait lui permettre de faire une bonne fin d\'année.',20);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les résultats ont baissés à cause de la difficulté des notions abordées, mais le travail de [prenom] a gagné en régularité ce trimestre.',20);

#### 21

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une belle progression ce trimestre qui est le fruit d\'un travail personnel de [prenom] tout à fait sérieux.',21);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('La progression espérée est au rendez-vous pour [prenom], il manque encore de la rigueur d\'apprentissage et de rédaction pour accéder à un niveau supérieur.',21);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une progression très encourageante qui est sûrement le fruit d\'un travail personnel consciencieux de [prenom]. Il faut continuer dans cette voie.',21);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Belle progression de [prenom] ce trimestre, on ne peut que l\'encourager à continuer dans cette voie.',21);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un bon trimestre de [prenom], un bon rythme de travail ce qui lui permet cette belle progression, c\'est encourageant. Maintenant il faut tenir jusqu\'à la fin de l\'année.',21);

#### 22

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le niveau de [prenom] est correct, mais il faut davantage de rigueur pour progresser.',22);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] nous montre sa capacité a fournir un bon travail. C\'est encourageant.',22);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Encore un bon trimestre de [prenom].',22);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Cette moyenne de [prenom] mérite mes félicitations. Bravo.',22);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail de [prenom] a été correct ce trimestre, continuer ainsi.',22);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a été capable de combler ses quelques difficultés par un travail personnel sérieux. Ce qui fait un trimestre tout à fait honorable. Il faut continuer ainsi.',22);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Quel plaisir d\'avoir une assiduité comme celle de [prenom] en classe. Continuer sur cette voie.',22);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le travail de [prenom] est de qualité. Félicitation.',22);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Encore un bon travail ce trimestre. L\'attitude de [prenom] est constante dans le travail et le sérieux. Bravo.',22);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Elève agréable en classe, et d\'un bon niveau. Continuer ainsi [prenom]',22);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un travail toujours de très bonne qualité pour [prenom], bravo.',22);


#### 23 T3

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] n\'est pas évaluable ce trimestre pour toutes ces absences.',23);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Beaucoup d\'absences et un niveau de compréhension très faible. Le bilan de l\'année est très décevant pour [prenom].',23);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Peu de note de devoir, le travail de [prenom] n\'est pas évaluable ce trimestre.',23);

#### 24

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les notes de [prenom] restent bien faibles, il faut songer à une réorientation.',24);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('La motivation de [prenom] s\'est quelque peu essoufflée malheureusement. Une deuxième année devrait lui être profitable, ce qui lui permettra d\'aborder l\'année prochaine avec confiance.',24);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Il manque toujours de la clarté dans les copies de [prenom]. Des lacunes persistent également. Une deuxième année sur le même programme devrait assurer des bases plus solides.',24);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une petite progression des résultats, mais les notes de l\'année restent insuffisantes. Une année de plus serait profitable à [prenom], pour acquérir les bonnes méthodes et assurer ses connaissances de base.',24);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] n\'a pas le bon rythme cette année, devrait refaire une année afin d\'assurer de bonnes bases.',24);


#### 25

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Il semble que [prenom] ait eu d\'autres préoccupations ce trimestre que cette matière. Cela ternit le bilan annuel.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le bilan annuel est bien terne pour [prenom].',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] manque de concentration dans son travail pour réussir.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Plus aucun travail, aucune motivation. C\'est bien dommage de la part de [prenom].',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un net relâchement ce trimestre pour [prenom], qui conclut une année très moyenne.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] n\'aime pas cette matière et cela se ressent tant dans ses notes que dans son attitude en classe. Je vous pense pourtant capable de bien faire.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un bon départ pour [prenom] mais la suite, ça a été la chute libre. Quel gâchis.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Abandont pour les dernières leçons, difficiles. Regrettable de la part de [prenom].',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] est constant dans cette matière, mais à un niveau très inquiétant.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] est capable de faire des efforts, mais par moments seulement. C\'est regrettable.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une démission progressive ce trimestre, alors qu\'il y avait de l\'amélioration en vue. Quel dommage [prenom].',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] est capable de travailler et de faire des efforts, mais par moments seulement. Un travail régulier est nécessaire.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] n\'a pas été au niveau tout au long de l\'année. Regrettable.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le niveau s\'étant accru, [prenom] n\'a pu avoir de meilleurs résultats. Il aurait fallu fournir davantage de travail personnel.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] n\'a pas su réagir après le deuxième trimestre comme il le fallait. C\'est bien décevant.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Je croyais que [prenom] avait un regain de motivation au début de ce trimestre, je m\'étais trompé.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Pour [prenom], la motivation n\'était plus là.',25);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les notes ont encore baissé pour [prenom]. C\'est regrettable.',25);

#### 26

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les résultats ont encore baissés ce trimestre pour [prenom], peut-être que la motivation était moins présente.',26);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] passe plus de temps au bavardage qu\'au travail, on voit le résultat.',26);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a réagir face à la baisse de la moyenne du deuxième trimestre. Il est dommage que la concentration en classe soit toujours limitée.',26);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une motivation et des notes en dents de scie ce trimestre. [prenom] n\'exploite pas totalement ses capacités.',26);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] pourrait être meilleure, si s\'en donnait plus les moyens. C\'est bien dommage.',26);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Toujours un gros problème de concentration pour [prenom] ce trimestre, ce qui nuit énormément à ses résultats.',26);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Peu de réaction de la part de [prenom] face à la dégringolade du deuxième trimestre. C\'est bien dommage.',26);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les résultats ont encore baissé ce trimestre, peut-être que la motivation était moins présente chez [prenom].',26);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] baisse progressivement les bras, malheureusement.',26);


#### 27

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une petite progression ce trimestre qui récompense les efforts de [prenom]. L\'année prochaine risque néanmoins d\'être difficile.',27);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le niveau est fragile sur l\'ensemble de l\'année pour [prenom]. Il faudra redoubler d\'effort pour l\'an prochain.',27);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Il semble que [prenom] fait des efforts de travail et de concentration. Cela paye. Mais le niveau reste bien juste pour aborder l\'année prochaine en confiance.',27);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un trimestre en dents de scie, comme l\'année d\'ailleurs. Il faudra beaucoup plus de régularité à [prenom] pour effectuer une bonne année l\'an prochain.',27);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une année bien terne pour [prenom], mauvais rythme de travail. L\'année prochaine sera difficile.',27);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le niveau de [prenom] est très juste pour l\'an prochain.',27);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une baisse ce trimestre due à une motivation toujours sporadique. Il faudra se méfier l\'an prochain et travailler très régulièrement. Cependant, le bilan annuel est positif pour [prenom].',27);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('L\'année est terne. Ce sera dur l\'an prochain pour [prenom].',27);

#### 28

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a bien travailler ce trimestre, malgré ses difficultés. Encourageant.',28);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Malgré le peu d\'intérêt pour la matière, [prenom] fait des efforts. Son attitude est tout à fait louable mais les résultats restent faibles.',28);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] fait des efforts pour comprendre et travailler les leçons. Malheureusement, le niveau est trop élevé pour lui.',28);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le comportement de [prenom] est sérieux en classe mais le niveau maintenant demandé est trop élevé pour avoir de meilleures notes.',28);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une attitude très positive toute l\'année, [prenom] se donne du mal et c\'est récompensée.',28);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a des difficultés. Mais le bilan de l\'année est positif.',28);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Les notions se sont encore compliquées ce trimestre, [prenom] peut mieux faire et je l\'encourage.',28);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Malgré un sérieux constant, [prenom] n\'a pas réussi à maintenir un niveau moyen, les notions abordées étant trop compliquées.',28);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] s\'accroche, c\'est une attitude tout à fait louable.',28);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Bon trimestre pour [prenom], ces notes en attestent. Le bilan de l\'année est tout à fait correct.',28);

#### 29

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Je félicite [prenom] pour cette belle progression. Il faudra rester sur ce rythme pour l\'année prochaine.',29);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un trimestre dans la continuité des deux précédents : assez satisfaisant. [prenom] devra garder le même état d\'esprit de travail pour l\'an prochain.',29);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une année satisfaisante pour [prenom] qui lui permettra d\'aborder l\'an prochain sereinement.',29);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un début de trimestre un peu juste qui se termine très bien. La régularité sera la clé d\'une bonne année pour [prenom].',29);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Je ne remets pas en cause le travail personnel de [prenom]. Par contre, peut-être que les méthodes sont à revoir pour réussir l\'année prochaine.',29);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une moyenne constante pour [prenom] cette année, pourtant il y a des irrégularités dans chaque trimestre. Il faudra régler ce problème pour l\'an prochain et tout devrait bien se passer.',29);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Le sérieux de [prenom] a payé tout au long de l\'année. Il faudra garder la même attitude l\'an prochain.',29);

#### 30

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un travail régulier tout au long du trimestre et de l\'année. Ce qui fait un bilan annuel satisfaisant pour [prenom].',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une belle progression tout au long de l\'année. [prenom] a fait des efforts de travail personnel ce qui s\'avère payant.',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un travail sérieux de [prenom] tout au long de l\'année. L\' prochain sera réussie avec le même état d\'esprit.',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un travail sérieux, une belle motivation. Bravo pour cette année réussie [prenom].',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une année satisfaisante. [prenom] gagnerait sûrement à se manifester davantage en classe.',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un beau trimestre qui clôt une année assez satisfaisante. Il semble néanmoins que quelques lacunes viennent perturber la progression de [prenom].',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une année qui fait la preuve de l\'importance du travail et de la motivation : [prenom] possède ces grands atouts qui lui permettront de réaliser une bonne année prochaine.',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une année tout à fait correcte pour [prenom]. De bonnes bases pour réussir une belle année prochaine.',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] termine l\'année en beauté. L\'année est satisfaisante et l\'an prochain devrait confirmer les qualités de [prenom].',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une baisse non significative ce trimestre : le bilan de l\'année est excellent. Bravo [prenom].',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un trimestre en dents de scie qui perturbe un peu la moyenne. L\'année de [prenom] est néanmoins assez satisfaisante. Bons atouts pour réussir son année prochaine.',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une attitude positive de [prenom] et un bon niveau toute l\'année, même si ce trimestre fût plus difficile. C\'est encourageant pour l\'an prochain.',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une attitude exemplaire tout au long de l\'année. Bravo [prenom].',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une belle constance cette année, à un bon niveau. Il faut maintenant que [prenom] s\'exprime davantage.',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un travail souvent de qualité de la part de [prenom]. Félicitation.',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un sérieux à toute épreuve, [prenom] fait preuve d\'une belle persévérance, et cela paye. Félicitation.',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] se donne les moyens de réussir, grâce à son sérieux et sa persévérance. Je vous en félicite.',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Une constance dans le sérieux et une attitude positive de [prenom]. Bravo.',30);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Un très bon trimestre pour clore une très bonne année pour [prenom]. Je vous en félicite.',30);

#### 31

INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] aligne les 0 et les 1 : devrait peut-être envisager une carrière dans l\'informatique.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Pourquoi cette moyenne pour [prenom] ? Vous comprendrez que lorsqu\'on dit que les femmes ont en moyenne 1,8 enfant, cela ne veut pas dire que le deuxième est manchot.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Si [prenom] veut devenir médecin, il va falloir se mettre sérieusement au travail et pas simplement imiter l\'écriture.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] doit arrêter d\'essayer de me jeter des sorts avec son jonglage de stylo. On n\'est pas à Poudlard ici, désolée de décevoir.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom], l\'ordre des mots dans la phrase vous devez revoir. Yoda.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a touché le fond mais creuse encor.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] ? Un vrai touriste prendrait des photos.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] s\'est parfois retourné... Pour regarder le tableau.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a les prétentions d\'un cheval de course mais les résultats d\'un âne.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('La plupart du temps, [prenom] est dans les nuages, n\'en descend que sous forme de perturbation.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] semble mobiliser toute son énergie à ne pas travailler.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] ? Elève sans Histoire... Et sans Géographie.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom]... La trousse à maquillage n\'est pas utile en cours, investissez dans un vrai crayon et pas pour les yeux.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] est sympathique mais travail inexistant: il faut essayer d\'essayer.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] a beaucoup de connaissances ... En dehors de l\'établissement.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] nourrit une haute idée de soi, que malheureusement ni ses résultats ni son attitude en classe ne permettent de partager.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('1er trimestre ? Touché. 2ème trimestre ? Touché. 3ème trimestre ? Coulé.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('Quand [prenom] sera une star, je pourrai dire que j\'ai assisté à ces premières séances de maquillage.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('[prenom] est doué en dessin... Mais nous ne sommes pas en cours d\'art plastique.',31);
INSERT INTO `projet_thelp`.`list_appreciation`(`appreciation`, `id_type`) VALUES ('I am not a rapper. [prenom] non plus et doit retirer sa casquette en cours.',31);

