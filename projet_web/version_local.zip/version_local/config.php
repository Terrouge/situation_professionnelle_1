<?php
/* Pour se connecter à la base de donnée MySQL  par la classe php mysqli*/

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');  //Identifiant MAMP par default pour MySQL
define('DB_PASSWORD', 'root');
define('DB_NAME', 'projet_thelp');

/* Tentative de connexion à la base de données MySQL */

$mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME); //classe mysqli
if($mysqli === false){
    die("La connexion au serveur MySQL a échoué");
}