<?php
session_start();    //Initialise la session
$_SESSION = array();    //Vide toutes les variables de session
session_destroy();  //Détruit la session
header("location: login.php");  //Redirection vers la page de connexion
exit;
?>