<?php
session_start();    //Initialise la session
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){     // Vérification si l'utilisateur est déjà connecté
    header("location: welcome.php");
    exit;
}
require_once "../config.php";   //Inclut config.php
// Definition des variables
$username = $password = "";
$username_err = $password_err = "";
// Traitement des données de formulaire lors de l'envoi du formulaire
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty(trim($_POST["username"]))){
        $username_err = "Veuillez entrer votre identifiant";
    } else{
        $username = trim($_POST["username"]);
    }
    if(empty(trim($_POST["password"]))){    // Vérifie si le champ mot de passe est vide
        $password_err = "Veuillez entrer votre mot de passe";
    } else{
        $password = trim($_POST["password"]);
    }
    // Valide les informations d'identification.
    if(empty($username_err) && empty($password_err)){
        // Préparation la requete SELECT
        $sql = "SELECT id, username, password FROM users WHERE username = ?";
        if($stmt = $mysqli->prepare($sql)){
            $stmt->bind_param("s", $param_username);     // Lie les variables à la requete comme paramètres
            $param_username = $username;    // Definit les paramètres
            // Tentative d'exécuter de la requete
            if($stmt->execute()){
                // Enmagasin le resultat
                $stmt->store_result();
                // Vérifie si l'utilisateur existe, si oui alors vérifie le mot de passe
                if($stmt->num_rows == 1){
                    // Lier les variables (résultat)
                    $stmt->bind_result($id, $username, $hashed_password);
                    if($stmt->fetch()){
                        if(password_verify($password, $hashed_password)){
                            // mot de passe est correct, alors démarer une nouvelle session
                            session_start();
                            // Enmagasin des données dans des variables de session
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;
                            // Redirige l'utilisateur à la page d'accueil
                            header("location: welcome.php");
                        } else{
                            // Afficher un message d'erreur si le mot de passe n'est pas valide
                            $password_err = "Le mot de passe que vous avez entré n'est pas valide";
                        }
                    }
                } else{
                    // Afficher un message d'erreur si l'utilisateur n'existe pas
                    $username_err = "Aucun compte trouvé avec cet identifiant";
                }
            } else{
                echo "Il y a eu une erreur. Veuillez réessayer plus tard.";
            }
        }
        // Fin de la requete
        $stmt->close();
    }
    // Fin de la connexion
    $mysqli->close();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Se connecter</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <link rel="apple-touch-icon" sizes="180x180" href="../favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../favicon/favicon-16x16.png">
    <link rel="manifest" href="../favicon/site.webmanifest">
    <link rel="mask-icon" href="../favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
</head>
<body class="text-center bodyLoginRegister">
    <!-- Le formulaire pour la connexion -->
    <form class="form-sign"  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <img class="mb-4" src="../img/logo.svg" alt="logo du site" height="100">
        <h1 class="h3 mb-3 font-weight-normal">Veuillez vous connecter</h1>
        <div class="<?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
            <label for="inputUsername" class="sr-only">Identifiant</label>
            <input type="text" id="inputUsername" name="username" class="form-control" placeholder="Identifiant" value="<?php echo $username; ?>" required autofocus>
            <span class="help-block"><?php echo $username_err; ?></span>
        </div>
        <div class="<?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
            <label for="inputPassword" class="sr-only">Mot de passe</label>
            <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Mot de passe" required>
            <span class="help-block"><?php echo $password_err; ?></span>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit" value="Connexion">Connexion</button>
        <div class="mb-3"><label>Vous n'avez pas de compte ? <a href="register.php">S'inscrire</a></label></div>
        <p class="mt-5 mb-3 text-muted"> &copy; 2018 Copyright<a href="https://adamdoursiev.com"> www.adamdoursiev.com</a></p>
    </form>
</body>
</html>