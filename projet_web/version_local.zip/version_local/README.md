# Projet web – Thelp générateur d'appréciation scolaire
version local et code commanté

Thelp est un web site développé en PHP/HTML5/CSS3/JS et du framework Boostrap, avec une base de donnée MySQL.
- Système d'authentification
- Générateur d'appréciation de bulletin scolaire

www.adamdoursiev.com