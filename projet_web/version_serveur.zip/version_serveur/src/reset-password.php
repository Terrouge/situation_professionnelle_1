<?php
session_start();
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
require_once "../config.php";
$new_password = $confirm_password = "";
$new_password_err = $confirm_password_err = "";
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty(trim($_POST["new_password"]))){
        $new_password_err = "Veuillez entrer le nouveau mot de passe.";     
    } elseif(strlen(trim($_POST["new_password"])) < 6){
        $new_password_err = "Le mot de passe doit comporter au moins 6 caractères.";
    } else{
        $new_password = trim($_POST["new_password"]);
    }
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "S'il vous plaît confirmer le mot de passe.";
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($new_password_err) && ($new_password != $confirm_password)){
            $confirm_password_err = "Le mot de passe ne correspond pas.";
        }
    }
    if(empty($new_password_err) && empty($confirm_password_err)){
        $sql = "UPDATE users SET password = ? WHERE id = ?";
        if($stmt = $mysqli->prepare($sql)){
            $stmt->bind_param("si", $param_password, $param_id);
            $param_password = password_hash($new_password, PASSWORD_DEFAULT);
            $param_id = $_SESSION["id"];
            if($stmt->execute()){
                session_destroy();
                header("location: login.php");
                exit();
            } else{
                echo "Il y a eu une erreur. Veuillez réessayer plus tard.";
            }
        }
        $stmt->close();
    }
    $mysqli->close();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Réinitialiser le mot de passe</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <link rel="apple-touch-icon" sizes="180x180" href="../favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../favicon/favicon-16x16.png">
    <link rel="manifest" href="../favicon/site.webmanifest">
    <link rel="mask-icon" href="../favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
</head>
<body class="text-center bodyLoginRegister">
    <form class="form-sign" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <img class="mb-4" src="../img/logo.svg" alt="logo du site" height="100">
        <h1 class="h3 mb-3 font-weight-normal">Réinitialiser le mot de passe</h1>
        <div <?php echo (!empty($new_password_err)) ? 'has-error' : ''; ?>>
            <label for="inputUsername" class="sr-only">Nouveau mot de passe</label>
            <input type="password" id="inputUsername" name="new_password" class="form-control" placeholder="Nouveau mot de passe" value="<?php echo $new_password; ?>" required autofocus>
            <span class="help-block"><?php echo $new_password_err; ?></span>
        </div>
        <div <?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>>
            <label for="inputConfirm_password" class="sr-only">Confirmation du mot de passe</label>
            <input type="password" id="inputConfirm_password" name="confirm_password" class="form-control" placeholder="Confirmation du mot de passe" required>
            <span class="help-block"><?php echo $confirm_password_err; ?></span>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit" value="Changer">Changer</button>
        <a class="btn btn-link" href="welcome.php">Annuler</a>
        <p class="mt-5 mb-3 text-muted"> &copy; 2018 Copyright<a href="https://adamdoursiev.com"> www.adamdoursiev.com</a></p>
    </form>
</body>
</html>