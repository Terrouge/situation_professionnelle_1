<?php
require_once "../config.php";
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty(trim($_POST["username"]))){
        $username_err = "Merci d'entrer un nom d'utilisateur.";
    } else{
        $sql = "SELECT id FROM users WHERE username = ?";
        if($stmt = $mysqli->prepare($sql)){
            $stmt->bind_param("s", $param_username);
            $param_username = trim($_POST["username"]);
            if($stmt->execute()){
                $stmt->store_result();
                if($stmt->num_rows == 1){
                    $username_err = "Ce nom d'utilisateur est déjà pris.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Il y a eu une erreur. Veuillez réessayer plus tard.";
            }
        }
        $stmt->close();
    }
    if(empty(trim($_POST["password"]))){
        $password_err = "Veuillez entrer un mot de passe.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Le mot de passe doit comporter au moins 6 caractères.";
    } else{
        $password = trim($_POST["password"]);
    }
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "S'il vous plaît confirmer le mot de passe.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Le mot de passe ne correspond pas.";
        }
    }
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err)){
        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
        if($stmt = $mysqli->prepare($sql)){
            $stmt->bind_param("ss", $param_username, $param_password);
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            if($stmt->execute()){
                header("location: login.php");
            } else{
                echo "Il y a eu une erreur. Veuillez réessayer plus tard.";
            }
        }
        $stmt->close();
    }
    $mysqli->close();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Enregistrement</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <link rel="apple-touch-icon" sizes="180x180" href="../favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../favicon/favicon-16x16.png">
    <link rel="manifest" href="../favicon/site.webmanifest">
    <link rel="mask-icon" href="../favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
</head>
<body class="text-center bodyLoginRegister">
    <form class="form-sign" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <img class="mb-4" src="../img/logo.svg" alt="logo du site" height="100">
        <h1 class="h3 mb-3 font-weight-normal">Création d'un compte</h1>
        <div class="<?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
            <label for="inputUsername" class="sr-only">Identifiant</label>
            <input type="text" id="inputUsername" name="username" class="form-control" placeholder="Identifiant" value="<?php echo $username; ?>" required autofocus>
            <span class="help-block"><?php echo $username_err; ?></span>
        </div>
        <div class="<?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
            <label for="inputRegisPassword" class="sr-only">Mot de passe</label>
            <input type="password" id="inputRegisPassword" name="password" class="form-control" value="<?php echo $password; ?>" placeholder="Mot de passe" required>
            <span class="help-block"><?php echo $password_err; ?></span>
        </div>
        <div class="<?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>">
            <label for="inputConfirm_password" class="sr-only">Confirmation du mot de passe</label>
            <input type="password" id="inputConfirm_password" name="confirm_password" class="form-control" value="<?php echo $confirm_password; ?>" placeholder="Confirmation du mot de passe" required>
            <span class="help-block"><?php echo $confirm_password_err; ?></span>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit" value="Valider">Créer</button>
        <div class="mb-3"><label>Vous avez déjà un compte ? <a href="login.php">Se connecter</a></label></div>
        <p class="mt-5 mb-3 text-muted"> &copy; 2018 Copyright:<a href="https://adamdoursiev.com"> www.adamdoursiev.com</a></p>
    </form>
</body>
</html>