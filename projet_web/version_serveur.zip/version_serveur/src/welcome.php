<?php
session_start();
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
require_once "../config.php";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Acceuil</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <link rel="apple-touch-icon" sizes="180x180" href="../favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../favicon/favicon-16x16.png">
    <link rel="manifest" href="../favicon/site.webmanifest">
    <link rel="mask-icon" href="../favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
</head>
<body class="text-center bodyWelcolme">
    <div class="welcolme-container d-flex h-100 p-3 mx-auto flex-column">
        <header class="header mb-auto">
            <div class="inner">
                <nav class="navbar navbar-light bg-light">
                    <a class="navbar-brand" href="#">
                        <img src="../img/logo.svg" width="70" class="d-inline-block align-top" alt="logo du site">
                    </a>
                    <a class="nav-link" href="reset-password.php">Réinitialiser le mot de passe</a>
                    <a class="nav-link active" href="logout.php">Se déconnecter</a>
                </nav>
            </div>
        </header>
        <main class="inner">
            <form class="form-inline" method="post" action="welcome.php">
                <label class="sr-only" for="prenom">Prénom</label>
                <input value="<?php echo htmlentities($_POST['prenom'])?>" name="prenom" type="text" class="form-control mb-2 mr-sm-2" id="prenom" placeholder="Prénom">
                <div class="mb-2 btn-group btn-group-toggle" data-toggle="buttons" >
                    <label class="btn btn-secondary">
                        <input type="radio" name="options" id="trimestre1" onclick="trimestreVisible1()"> TRIMESTRE 1
                    </label>
                    <label class="btn btn-secondary">
                        <input type="radio" name="options" id="trimestre2" onclick="trimestreVisible2()"> TRIMESTRE 2
                    </label>
                    <label class="btn btn-secondary">
                        <input type="radio" name="options" id="trimestre3" onclick="trimestreVisible3()"> TRIMESTRE 3
                    </label>
                </div>
                <label class="sr-only" for="typelist">Type d'appréciation</label>
                <select  class="form-control mb-2 mr-sm-2" id="typelist" name="typelist">
                    <?php
                    $query = "SELECT id, nom_type, trimestre FROM type_appreciation ORDER BY id ASC";
                    if ($stmt = $mysqli->prepare($query)) {
                        $stmt->execute();
                        $stmt->bind_result($id, $nom, $trimestre);
                        while ($stmt->fetch()) {
                            printf ('<option value="'.$id.'" class="visible'.$trimestre.'">'.$nom.'</option>');
                        }
                        $stmt->close();
                    }
                    ?>
                    <option value="<?php echo htmlentities($_POST['typelist'])?>" selected><?php echo $nom = (empty(htmlentities($_POST['typelist']))) ? 'Le type d\'appréciation...': 'Générer une nouvelle appréciation' ?></option>
                </select>
                <button type="submit" class="btn btn-primary mb-2" style="width: 176px">Générer</button>
            </form>
            <label class="sr-only" for="appreciation">Résultat</label>
            <textarea id="appreciation" rows="4" cols="65"><?php
                $query = "SELECT appreciation FROM list_appreciation WHERE id_type = ? ORDER BY RAND() LIMIT 1";
                if ($stmt = $mysqli->prepare($query)) {
                    $stmt->bind_param("s", $param_type);
                    $param_type = trim($_POST["typelist"]);
                    $param_prenom = (empty($_POST['prenom'])) ? 'Prenom' : $_POST['prenom'];trim($_POST["prenom"]);
                    $stmt->execute();
                    $stmt->bind_result($id);
                    while ($stmt->fetch()) {
                        printf (str_replace("[prenom]",$param_prenom,$id));
                    }
                    $stmt->close();
                }
            ?></textarea>
        </main>
        <footer class="mastfoot mt-auto">
            <div class="inner">
                <p class="mt-5 mb-3 text-muted"> &copy; 2018 Copyright<a href="https://adamdoursiev.com"> www.adamdoursiev.com</a></p>
            </div>
        </footer>
        <script>
            function trimestreVisible1() {
                var el1 = document.getElementsByClassName('visible1');
                var el2 = document.getElementsByClassName('visible5');
                var el3 = document.getElementsByClassName('visible6');
                while (el1.length > 0) {
                    el1[0].className = 'visible4';
                }
                while (el2.length > 0) {
                    el2[0].className = 'visible2';
                }
                while (el3.length > 0) {
                    el3[0].className = 'visible3';
                }
            }
            function trimestreVisible2() {
                var el1 = document.getElementsByClassName('visible2');
                var el2 = document.getElementsByClassName('visible4');
                var el3 = document.getElementsByClassName('visible6');
                while (el1.length > 0) {
                    el1[0].className = 'visible5';
                }
                while (el2.length > 0) {
                    el2[0].className = 'visible1';
                }
                while (el3.length > 0) {
                    el3[0].className = 'visible3';
                }
            }
            function trimestreVisible3() {
                var el1 = document.getElementsByClassName('visible3');
                var el2 = document.getElementsByClassName('visible4');
                var el3 = document.getElementsByClassName('visible5');
                while (el1.length > 0) {
                    el1[0].className = 'visible6';
                }
                while (el2.length > 0) {
                    el2[0].className = 'visible1';
                }
                while (el3.length > 0) {
                    el3[0].className = 'visible2';
                }
            }
        </script>
    </div>
</body>
</html>